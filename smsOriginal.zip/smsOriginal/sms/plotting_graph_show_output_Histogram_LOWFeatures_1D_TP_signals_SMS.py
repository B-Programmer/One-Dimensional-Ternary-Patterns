import numpy as np
import matplotlib.pyplot as plt
def plotting_graph_show_output_Histogram_LOWFeatures_1D_TP_signals_SMS(lowHistValues, lowHistFreq, P, B):
    # Plotting a graph to show the output of the Histogram of the LOWFeatures 1D-TP signals for the SMS
    fig2 = plt.figure(5)
    x = lowHistValues
    y = lowHistFreq
    plt.plot(x, y, color='gray', linestyle='dashed', marker='*', markerfacecolor='black', markersize=12)
    titleIt = "Graph of the 1D-TP Histogram(Lower) for SMS Message at P = "+str(P) +" and B = "+str(B)
    plt.title(titleIt)
    plt.ylabel("Frequency")
    plt.xlabel("Unique Value for lowFeatures")
    # plt.colorbar()
    plt.show()


