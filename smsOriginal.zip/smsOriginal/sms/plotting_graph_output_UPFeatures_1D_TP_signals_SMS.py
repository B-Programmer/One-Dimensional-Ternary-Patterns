import numpy as np
import matplotlib.pyplot as plt
def plotting_graph_output_UPFeatures_1D_TP_signals_SMS(upFeaturesList, P, B):
    # Plotting a graph to show the output of the UPFeatures 1D-TP signals for the SMS
    fig2 = plt.figure(2)
    x = np.arange(0, len(upFeaturesList))
    y = upFeaturesList
    plt.plot(x, y, color='yellow', linestyle='dashed', marker='*', markerfacecolor='red', markersize=12)
    titleIt = "Graph of the 1D-TP signal(Upper) for SMS Message at P ".replace("'", "") +str(P).replace("'", "") +" and B = " +str(B).replace("'", "")
    plt.title(titleIt)
    plt.ylabel("UPFeatures values")
    plt.show()