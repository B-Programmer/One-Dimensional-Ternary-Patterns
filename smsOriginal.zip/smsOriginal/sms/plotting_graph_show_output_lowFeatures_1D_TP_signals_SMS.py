import numpy as np
import matplotlib.pyplot as plt
def plotting_graph_show_output_lowFeatures_1D_TP_signals_SMS(lowFeaturesList, P, B):
    # Plotting a graph to show the output of the lowFeatures 1D-TP signals for the SMS
    fig2 = plt.figure(3)
    x = np.arange(0, len(lowFeaturesList))
    y = lowFeaturesList
    plt.plot(x, y, color='brown', linestyle='dashed', marker='o', markerfacecolor='white', markersize=12)
    titleIt = "Graph of the 1D-TP signal(Lower) for SMS Message at P = "+str(P) +" and B = "+str(B)
    plt.title(titleIt)
    plt.ylabel("LowFeatures value")
    plt.show()
