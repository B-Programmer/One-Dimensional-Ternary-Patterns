import numpy as np
import matplotlib.pyplot as plt
def plotting_graph_show_output_Histogram_UPFeatures_1D_TP_signals_SMS(upHistValues, upHistFreq, P, B):
    # Plotting a graph to show the output of the Histogram of the UPFeatures 1D-TP signals for the SMS
    fig2 = plt.figure(4)
    x = upHistValues
    y = upHistFreq
    plt.plot(x, y, color='teal', linestyle='dashed', marker='o', markerfacecolor='green', markersize=12)
    titleIt = "Graph of the 1D-TP Histogram(Upper) for SMS Message at P = "+str(P) +" and B = "+str(B)
    plt.title(titleIt)
    plt.ylabel("Frequency")
    plt.xlabel("Unique Value for upFeatures")
    plt.show()