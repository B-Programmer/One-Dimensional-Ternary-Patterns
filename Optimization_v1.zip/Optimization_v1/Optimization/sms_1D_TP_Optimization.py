## #This is a python application that performs the operation of evaluating the optimal value of B and P for feature extraction on a given sms using One-Dimensional Ternary Patterns Transformation
# Import some other libraries that we'll need
# matplotlib and numpy packages must also be installed
import matplotlib
import numpy as np
import matplotlib.pyplot as plt
import random
import math

#+++++++++++++++++++++++++++ THIS IS FOR THE NORMAL 1D-TP OPERATION ON SMS WHICH IS INVOKED IN THE OPTIMIZATION PART ++++++++++++++++++++++++++++++++++++++++++++++++
#Creating a function to convert binary to decimal
def binaryToDecimal(binaryList):
	decimal, n = 0, len(binaryList)	
	for b in binaryList:
		decimal += b*2**(n-1)
		n -= 1
	return decimal

#Define a function to perform the 1D-TP feature extraction on SMS
def perform1DTPOnSMS(x1, x2):
	#Read the given SMS
	originalSMS = "URGENT!! Your 4* Costa Del Sol Holiday or £5000 await collection. Call 09050090044 Now toClaim. SAE, TC s, POBox334, Stockport, SK38xh, Cost£1.50/pm, Max10mins"
	#Remove all flux from the SMS
	originalSMS = originalSMS.replace(" ","")
	print("The given sms: ", originalSMS, " with length: ", len(originalSMS))
	SMS_length = len(originalSMS)
	#Set the initial value of P
	P = x2
	#Get the number of possible pattern P that can be formed on the SMS
	noOfPatterns = SMS_length//(P+1)
	print("The number of pattern is: ", noOfPatterns, " and value of P is: ", P)
	upFeaturesList, lowFeaturesList = [],[]
	n, step = 1, P+1
	for k in range(0, (noOfPatterns*step), step):
		text = originalSMS[k:n*step]
		print("Pattern ",n," Text is: ", text)
		#Partition the text into 3 list(Pl, Pr, Pc)
		Lp, Cp, Rp = text[:P//2], text[P//2:P//2+1], text[P//2+1:] 
		print("The left list is: ", Lp)
		print("The centre list is: ", Cp)	
		print("The right list is: ", Rp)
		#Get the UTF-8 of the characters in the given SMS text pattern	
		Pl, Pr, Pc = [],[], ord(Cp)
		for i in range(0,len(Lp)):
			Pl.insert(i, ord(Lp[i]))
		for i in range(0,len(Rp)):
			Pr.insert(i, ord(Rp[i]))
		print("The left list is: ", Pl)
		print("The centre list is: ", Pc)	
		print("The right list is: ", Pr)
		#Set the threshold value and perform the 1D-TP transformation
		B = x1
		print("The value of B is: ", B)
		#Comparison of Pc with neighbors (Pi), 
		Tpl, Tpr = [],[]
		for i in range(0,len(Lp)):
			if(Pc > (Pl[i] + B)):		
				Tpl.insert(i, 1)
			elif(Pc <= (Pl[i] + B) and Pc >= (Pl[i] - B)):		
				Tpl.insert(i, 0)
			elif(Pc < (Pl[i] - B)):		
				Tpl.insert(i, -1)
		for i in range(0,len(Rp)):
			if(Pc > (Pr[i] + B)):		
				Tpr.insert(i, 1)
			elif(Pc <= (Pr[i] + B) and Pc >= (Pr[i] - B)):		
				Tpr.insert(i, 0)
			elif(Pc < (Pr[i] - B)):		
				Tpr.insert(i, -1)
		print("The left list is: ", Tpl)
		print("The right list is: ", Tpr)
		#Separation positive and negative values,	
		upF, lowF = [],[]
		for i in range(0,len(Lp)):
			if(Tpl[i] == -1):		
				upF.insert(i, 0)
				lowF.insert(i, 1)
			else:		
				upF.insert(i, Tpl[i])
				lowF.insert(i, 0)
		for i in range(0,len(Rp)):
			if(Tpr[i] == -1):		
				upF.insert(len(Lp)+i, 0)
				lowF.insert(len(Lp)+i, 1)
			else:		
				upF.insert(len(Lp)+i, Tpr[i])
				lowF.insert(len(Lp)+i, 0)
		print("The up list is: ", upF)
		print("The low list is: ", lowF)
		#Conversion of binary values to decimal	
		upFeatures = binaryToDecimal(upF)
		lowFeatures = binaryToDecimal(lowF)
		print("The upFeatures is: ", upFeatures)
		print("The lowFeatures is: ", lowFeatures)
		#Populate the both upFeatures List and lowFeaturesList
		upFeaturesList.insert(n-1, upFeatures)
		lowFeaturesList.insert(n-1, lowFeatures)
		#increase the value of n for the pattern to be selected for computation
		n += 1
	print("The upFeatures List is: ", upFeaturesList)
	print("The lowFeatures List is: ", lowFeaturesList)
	avg = 0.0
	if(len(upFeaturesList) != 0): 
		avg = sum(upFeaturesList)/len(upFeaturesList)
	return avg

#============================== OPTIMIZATION PART USING SIMULATED ANNEALING ALGORITHM ========================================================
# define the objective function 
def f(x):
	x1 = x[0]
	x2 = x[1]
	if(x2 < 6):
		x2 = abs(x2) + 6
	obj = perform1DTPOnSMS(int(abs(x1)), int(abs(x2)))
	return obj

# Start initial value for B and P
x_start = [4, 6]

# Design variables at mesh points
i1 = np.arange(-10.0,10.0, 0.01)
i2 = np.arange(-10.0, 10.0, 0.01)
x1m, x2m = np.meshgrid(i1, i2)
fm = np.zeros(x1m.shape)
for i in range(x1m.shape[0]):
    for j in range(x1m.shape[1]):
        fm[i][j] = 0.2 + x1m[i][j]**2 + x2m[i][j]**2 \
             - 0.1*math.cos(6.0*3.1415*x1m[i][j]) \
             - 0.1*math.cos(6.0*3.1415*x2m[i][j])

# Create a contour plot
plt.figure()
# Specify contour lines
#lines = range(2,52,2)
# Plot contours
CS = plt.contour(x1m, x2m, fm)#,lines)
# Label contours
plt.clabel(CS, inline=1, fontsize=10)
# Add some text to the plot
plt.title('Non-Convex Function')
plt.xlabel('B')
plt.ylabel('P')

##################################################
# Simulated Annealing
##################################################
# Number of cycles
n = 50
# Number of trials per cycle
m = 50
# Number of accepted solutions
na = 0.0
# Probability of accepting worse solution at the start
p1 = 0.7
# Probability of accepting worse solution at the end
p50 = 0.001
# Initial temperature
t1 = -1.0/math.log(p1)
# Final temperature
t50 = -1.0/math.log(p50)
# Fractional reduction every cycle
frac = (t50/t1)**(1.0/(n-1.0))
# Initialize x
x = np.zeros((n+1,2))
x[0] = x_start
xi = np.zeros(2)
xi = x_start
na = na + 1.0
# Current best results so far
xc = np.zeros(2)
xc = x[0]
fc = f(xi)
fs = np.zeros(n+1)
fs[0] = fc
# Current temperature
t = t1
# DeltaE Average
DeltaE_avg = 0.0
for i in range(n):
    print('Cycle: ' + str(i) + ' with Temperature: ' + str(t))
    for j in range(m):
        # Generate new trial points
        xi[0] = xc[0] + (random.random() - 0.5) * 8
        xi[1] = xc[1] + (random.random() - 0.5) * 20
        # Clip to upper and lower bounds
        xi[0] = max(min(xi[0],8.0),-8.0)
        xi[1] = max(min(xi[1],20.0),-20.0)
        DeltaE = abs(f(xi)-fc)
        if (f(xi)>fc):
            # Initialize DeltaE_avg if a worse solution was found
            #   on the first iteration
            if (i==0 and j==0): DeltaE_avg = DeltaE
            # objective function is worse
            # generate probability of acceptance
            p = math.exp(-DeltaE/(DeltaE_avg * t))
            # determine whether to accept worse point
            if (random.random()<p):
                # accept the worse solution
                accept = True
            else:
                # don't accept the worse solution
                accept = False
        else:
            # objective function is lower, automatically accept
            accept = True
        if (accept==True):
            # update currently accepted solution
            xc[0] = xi[0]
            xc[1] = xi[1]
            fc = f(xc)
            # increment number of accepted solutions
            na = na + 1.0
            # update DeltaE_avg
            DeltaE_avg = (DeltaE_avg * (na-1.0) +  DeltaE) / na
    # Record the best x values at the end of every cycle
    x[i+1][0] = xc[0]
    x[i+1][1] = xc[1]
    fs[i+1] = fc
    # Lower the temperature for next cycle
    t = frac * t

#Normalize the value of P
if(xc[1] < 6):
	xc[1] = abs(xc[1]) + 6
# print solution
print('Best solution with optimal value B is: ' + str(int(abs(xc[0]))) + ' and P is: ' + str(int(abs(xc[1]))))
print('Best objective(1D-TP): ' + str(int(fc)))

plt.plot(x[:,0],x[:,1],'y-o')
plt.savefig('contour.png')

fig = plt.figure()
plt.title("Graph of the Optimal solution for both P and B")
ax1 = fig.add_subplot(211)
ax1.plot(fs,'r.-')
ax1.legend(['Objective (1D-TP)'])
ax2 = fig.add_subplot(212)
ax2.plot(x[:,0],'b.-')
ax2.plot(x[:,1],'g--')
ax2.legend(['B','P'])


# Save the figure as a PNG
plt.savefig('optimization.png')

plt.show()
